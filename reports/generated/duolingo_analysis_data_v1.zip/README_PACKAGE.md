# Duolingo 分析数据移交包

版本 duolingo-analysis-v1.1-closeout-stage4-v2-stage5-v1；冻结2026-10-03。解压后在根目录运行。Windows图表使用Microsoft YaHei，当前实际Office为16.0。Notebook使用既有Anaconda Python3.13.5和analysis/requirements.txt版本；正式文稿使用bundled Python3.12.14/python-docx1.2.0/matplotlib3.11.2。bundled Python未提供nbformat/IPython，不能直接运行Notebook。CSV最小复核只需标准库。没有安装新依赖。

## 最小复核

先按[复现指南](docs/REPRODUCTION_GUIDE.md)选择只读核验或编辑重建；业务阅读入口为[最终交付](docs/FINAL_DELIVERY.md)，下一轮选择集中在[后续规划](docs/NEXT_PHASE_PLAN.md)。不必运行Word/Excel或Notebook即可完成以下标准库核验。

1. 核对MANIFEST.json的路径/哈希与CSV主键/粒度。不要把观察行数、URL或检查次数当用户样本。
2. `python -B scripts/rebuild_package_tables.py`只读校验公司输入QA、三张公司派生、四张v2派生、桥接三行及报告58图点。
3. `python -B scripts/run_stage4_final.py --check-only`对账当前v2；`python -B scripts/verify_stage4_final.py --check-only`提供另一条独立方法/边界复核。真实经济量仍为空。无D输入/输出。

## 重建与文稿

`python -B scripts/run_stage3.py --execute-direct`需要nbformat、IPython、matplotlib等现有分析依赖，在新Python进程执行公司Notebook；`python -B scripts/run_stage4_final.py --execute-direct`需要nbformat。交互Jupyter/ZeroMQ未通过。

`python -B scripts/build_final_documents.py`使用bundled python-docx/matplotlib重建Word和四图；`powershell -File scripts/export_final_documents.ps1`用本地隐藏Word COM导出同版PDF；`python -B scripts/render_final_pdfs.py experiments/test_plan.pdf reports/executive_decision_book.pdf`以bundled Poppler渲染验收。Office版本、字体与可用授权会影响导出；没有声称跨系统排版完全一致。

监控由build_monitoring_dashboard.mjs/py/ps1生成，使用bundled artifact-tool；实际保存/导出边界见reports/monitoring_design.md。Excel COM重算与原生图测试通过，但许可到期导致Save/原生PDF导出失败；正式PDF为重新导入最终xlsx的同版sheet渲染快照，不能称Excel打印输出或生产监控。

## 分析边界

经济/政策未知保留null或CSV空白，不是0；不提供真实ROI、MDE/N、学习/经营uplift、总体预测或已执行试验。市场竞争表为同任务供给与风险，不是满意度/效果排名。原文网页到CSV是人工有限核读；用户私有298条记录未打包，其总量及提交标签聚合无法从这个公开包独立重建。当前部署/资格、完整研究PDF与真实成本仍有缺口。

PDF/Word/Excel为本项目自己的产物；原资料只通过必要事实、自行概括及URL提供，未附全文再分发授权。所有列表采用白名单，不打包目录。MANIFEST.json不含自身哈希，验证时对其版本、清单结构与成员集合另查；CRC/哈希不认证来源或因果。

这是最小复现包，并非整个项目仓库：历史文档中提到但未列入MANIFEST的材料只在仓库保留。Stage4原验收记录包含全仓库审核对象，不要求包内复跑该历史closeout；包内采用上述当前模型/独立校验。仓库reports/final_delivery_validation.json记录本ZIP校验，避免循环哈希不收入本ZIP。监控六份实际QA收据已收入包。
